=== Robolabs ===

### LT ###

Modulis skirtas sinchronizuoti produktus ir užsakymus tarp Prestashop ir Robolabs.

### Reikalavimai ###

* PHP 7.2.1 (Min 7.0)
* Prestashop > (Min 1.7)

### Diegimas ###

*  Pirma reikia pasirinkti "Moduliai" -> "Module manager" -> "Įkelti modulį".
*  Viršuje spauskite mygtuką Įkelti modulį.
*  Pasirinkite robolabs.zip failą ir paspauskite įdiegti dabar.


### Dokumentacija ####

1. Į API kodas laukelį įrašykite duotą api kodą kuris randasi robolabs sistemoje, kompanijos profilis lange, puslapio apačioje skiltyje ROBO API.
2. Į Sinchronizacijos data nuo laukelį įrašykite datą nuo kurios norite sinchronizuoti užsakymus formatu YYYY-MM-DD.
3. Į sąskaitų serijos laukelį įrašykite savo sąskaitų serijos pavadinimą.
4. Į sandelio pavadinimo laukelį įrašykite savo sukurto sandėlio pavadinimą kaip robolabs sistemoje, o jei nekūrėte jokio sandėlio įrašykite WH.
5. Į serverio nuorodos laukelį įrašykite URL kuriuo jungiates prie robolabs sistemos pvz:https://api.robolabs.lt
6. Pasirinkite produktų sinchronizacijos būdą.
7. Viską užpildžius spauskite mygtuką išsaugoti.

Papildoma informacija
1. Sistema užsakymus sinchronizuos tik tuos kurie yra įvykdyti.
2. Iš robolabs sistemos produktus į prestashop atvaizduos kaip juodraščius.
3. Prekės neturinčios prekės kodo nebus siunčiamos iš prestashop į robolabs.
4. Kad užsakymai būtų tinkamai siunčiami, savo apmokėjimo puslapyje turite turėti DNI ir PVM mokėtojo kodą. Norėdami juos pridėti, eikite į skyrių Tarptautinis -> Vietovės -> Šalys -> Pasirinkite savo šalį ir pridėkite "dni" ir "vat_number" prie adreso formato lauko.

Informacija apie Cron Jobs
1. Pridėkite visus išvardytus Cron Job URL, nurodytus modulio konfigūracijos puslapyje, į serverio Cron Job darbų sąrašą.
2. Cron Jobs galite pridėti per serverio valdymo skydą („DirectAdmin“, „Cpanel“).
3. Įtraukite šią eilutę į savo Cron Job komandą: wget -q -O /dev/null "[CRON JOB URL]" > /dev/null 2>&1 Vietoj [CRON JOB URL] reikia nurodyti savo Cron adresą.
4. Kai pridedate Cron Jobs prie serverio, pasirinkite laiką vieną kartą per dieną vidurnaktį


### Kontaktai ###

* Kilus klausimams, prašome kreiptis hello@robolabs.lt



### EN ###

=== Robolabs ===

The plugin is designed to synchronize products and orders between Prestashop and Robolabs.

### Requirements ###

* PHP 7.2.1 (Min 7.0)
* Prestashop> (Min 1.7)

### Installation ###

* First you need to select "Modules" -> "Module manager" -> "Upload a module".
* Click the Upload Plugin button at the top.
* Select the robolabs.zip file and click install now.


### Documentation ####

1. In the API code field, enter the given api code found in the robolabs system, in the company profile window, in the ROBO API section at the bottom of the page.
2. In the Sync date from field, enter the date from which you want to synchronize orders in the format YYYY-MM-DD.
3. Enter the name of your invoice series in the Invoice Series field.
4. In the warehouse name field, enter the name of the warehouse you created as in robolabs, and if you have not created any warehouse, enter WH.
5. In the server shortcut field, enter the URL you use to connect to the robolabs system, for example: https: //api.robolabs.lt
6. Select a method for synchronizing products.
7. When everything is complete, click the save button.

Additional information
1. The system will synchronize orders only those that are completed.
2. The products from the robolabs system to Prestashop will be displayed as drafts.
3. Products that do not have SKU code will not be sent from Prestashop to robolabs.
4. You must have DNI and vat number at your checkout fields for orders to send properly. To add them go to International -> Locations -> Countries -> Choose your country and add DNI and vat number to adress format field.

Cron Job information
1. Add all the listed Cron Jobs URLs listed on the module configuration page to the server Cron job list.
2. You can add Cron Jobs via the server control panel (DirectAdmin, Cpanel)
3. Add this line to your Cron Job command: wget -q -O /dev/null "[CRON JOB URL]" > /dev/null 2>&1 You must specify your Cron address instead of [CRON JOB URL].
4. When adding Cron Jobs to a server select a time once per day at midnight

### Contacts ###

* If you have any questions, please contact hello@robolabs.lt


