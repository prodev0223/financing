=== Robolabs ===

### LT ###

Įskiepis skirtas sinchronizuoti produktus ir užsakymus tarp WooCommerce ir Robolabs.

### Reikalavimai ###

* PHP 7.2.1 (Min 7.0)
* Wordpress >4.9.4
* WooCommerce >3.3.1

### Diegimas ###

*  Pirma reikia pasirinkti "Įskiepiai" -> "Įdiegti įskiepį".
*  Viršuje spauskite mygtuką Įkelti įskiepį.
*  Pasirinkite robolabs.zip failą ir paspauskite įdiegti dabar. 
*  Tada nuekite į "Įskiepiai" -> "Įdiegti įskiepiai" ir aktyvuokite įskiepį.


### Dokumentacija ####

1. Į API kodas laukelį įrašykite duotą api kodą kuris randasi robolabs sistemoje, kompanijos profilis lange, puslapio apačioje skiltyje ROBO API.
2. Į Sinchronizacijos data nuo laukelį įrašykite datą nuo kurios norite sinchronizuoti užsakymus formatu YYYY-MM-DD.
3. Į sąskaitų serijos laukelį įrašykite savo sąskaitų serijos pavadinimą.
4. Į sandelio pavadinimo laukelį įrašykite savo sukurto sandėlio pavadinimą kaip robolabs sistemoje, o jei nekūrėte jokio sandėlio įrašykite WH.
5. Į serverio nuorodos laukelį įrašykite URL kuriuo jungiates prie robolabs sistemos pvz:https://api.robolabs.lt
6. Pasirinkite produktų sinchronizacijos būdą.
7. Viską užpildžius spauskite mygtuką išsaugoti.
8. Paspauskite mygtuką inicijuoti, kad sistema pradėtų duomenų sinchronizaciją.
9. Po iniciacijos sistema kiekvieną dieną automatiškai sinchronizuos duomenis.
Papildoma informacija
1. Sistema užsakymus sinchronizuos tik tuos kurie yra įvykdyti.
2. Iš robolabs sistemos produktus į woocommerce atvaizduos kaip juodraščius.
3. Prekės neturinčios prekės kodo nebus siunčiamos iš woocommerce į robolabs.

### Kontaktai ###

* Kilus klausimams, prašome kreiptis hello@robolabs.lt



### EN ###

=== Robolabs ===

The plugin is designed to synchronize products and orders between WooCommerce and Robolabs.

### Requirements ###

* PHP 7.2.1 (Min 7.0)
* Wordpress> 4.9.4
* WooCommerce> 3.3.1

### Installation ###

* First you need to select "Plugins" -> "Add new".
* Click the Upload Plugin button at the top.
* Select the robolabs.zip file and click install now.
* Then go to "Plugins" -> "Installed Plugins" and activate the plugin.


### Documentation ####

1. In the API code field, enter the given api code found in the robolabs system, in the company profile window, in the ROBO API section at the bottom of the page.
2. In the Sync date from field, enter the date from which you want to synchronize orders in the format YYYY-MM-DD.
3. Enter the name of your invoice series in the Invoice Series field.
4. In the warehouse name field, enter the name of the warehouse you created as in robolabs, and if you have not created any warehouse, enter WH.
5. In the server shortcut field, enter the URL you use to connect to the robolabs system, for example: https: //api.robolabs.lt
6. Select a method for synchronizing products.
7. When everything is complete, click the save button.
8. Press the initialize button to start synchronizing the system.
9. After initialization, the system will automatically synchronize the data every day.
Additional information
1. The system will synchronize orders only those that are completed.
2. The products from the robolabs system to woocommerce will be displayed as drafts.
3. Products that do not have SKU code will not be sent from woocommerce to robolabs.

### Contacts ###

* If you have any questions, please contact hello@robolabs.lt


