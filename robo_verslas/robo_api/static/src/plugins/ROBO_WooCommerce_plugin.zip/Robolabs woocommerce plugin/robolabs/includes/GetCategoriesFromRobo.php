<?php

Function get_categories_from_robo()
{

      
                    $api = get_option('robolabs_api_code');
                    $endpoint = get_option('server_url');
                    $data_api = array(
                        'secret' => $api,
                        'execute_immediately' => true,
                        );
                                // send API request via cURL
                  
                          $ch = curl_init();
                          
                          
                          curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/product_categories");
                  
                          curl_setopt($ch, CURLOPT_POST, 1);
                  
                          curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api));
                          
                          curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                  
                          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                          
                          curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                          

                          curl_setopt($ch, CURLOPT_VERBOSE, 1);
                          curl_setopt($ch, CURLOPT_HEADER, 1);
                          // ...
                        
                          $response = curl_exec($ch);

                          // Then, after your curl_exec call:
                          $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                          $header = substr($response, 0, $header_size);
                          $body = substr($response, $header_size);                                               
                          curl_close ($ch);
                          
                          
                          $categories = json_decode($body, true);
                          foreach ($categories["result"]["data"] as $kategoriju_masyvas)
                                {
                                $name =  $kategoriju_masyvas['name'];
                                $args = array(
                                        'taxonomy' => "product_cat",
                                        'name' => $name,
                                            );
                                $nameslug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $name), '-'));
                              $all_categories = get_categories( $args );
                              if( empty($all_categories) )
                              {
                                   wp_insert_term( $name,  'product_cat', array(
                                                                        	'description' => '',
                                                                        	'slug'        => $nameslug,
                                                                        ) ); 
                                      
                              }
 
               
          }
          
              $logs = json_decode($body, true);
              $status_code = $logs['result']['status_code'];
              $error = $logs['result']['error']; 
              $pluginlog = plugin_dir_path(__FILE__).'debug.log';
              $message = date('Y-m-d H:i:s') ." " ."[Get categories from robolabs]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
              error_log($message, 3, $pluginlog); 
          
            
    }

add_action ('Cron_categories_from_robo', 'get_categories_from_robo');