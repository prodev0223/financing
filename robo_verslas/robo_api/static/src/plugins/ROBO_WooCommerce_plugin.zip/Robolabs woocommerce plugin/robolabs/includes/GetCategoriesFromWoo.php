<?php 


function get_categories_from_woo()
{

              
              $api = get_option('robolabs_api_code');
              $endpoint = get_option('server_url');
              $hide_empty = false ;
              $args = array(
                          'taxonomy' => "product_cat",
                          'hide_empty' =>  $hide_empty,
  );
              $all_categories = get_categories( $args );
              foreach ($all_categories as $cat) 
              {
                   $category_name = $cat->name;
                    $products = wc_get_products(array(
                    
                      'terms' => $cat->term_id,
                      'numberposts' => 1,
                      
                ) );
                  
                foreach($products as $preke)
              {
                 if ($preke-> is_virtual('yes')) 
                        {
                            $type = "services";
                        }
                        else
                        {
                            $type = "products";
                        }

                }   
                   $cat_data = array (
                                            
                            'secret' => $api,
                            'name' => $category_name,
                            'type' => $type,
                            'execute_immediately' => true,

                      );
                      
                      $catID = $cat->term_id;
                      
                    $successfull_categories = get_option('successfull_categories');
                    

                    if(!in_array($catID, $successfull_categories))
                    {   
                      
                    $ch = curl_init();
        
                    curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/create_product_category");
            
                    curl_setopt($ch, CURLOPT_POST, 1);
            
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($cat_data));
                    
                    curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
            
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    
                    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                    
                    curl_setopt($ch, CURLOPT_VERBOSE, 1);
                    
                    curl_setopt($ch, CURLOPT_HEADER, 1);
                  
                    $response = curl_exec($ch);
            
                    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                    $header = substr($response, 0, $header_size);
                    $body = substr($response, $header_size);
                                                                    
                    curl_close ($ch);
                    
                    //echo $body;
                    
                    $tikrinimas = json_decode($body, true);
                    $tikrinimo_status_code = $tikrinimas['result']['status_code'];
                    $tikrinimo_error = $tikrinimas['result']['error'];
                    if($tikrinimo_status_code == 200 or $tikrinimo_error == "Category with this name already exists.")
                          {
                          array_push($successfull_categories, $catID);
                          update_option('successfull_categories' , $successfull_categories);
                          }
                    }
                   
              } 
              
              
              
              $logs = json_decode($body, true);
              $status_code = $logs['result']['status_code'];
              $error = $logs['result']['error']; 
              $pluginlog = plugin_dir_path(__FILE__).'debug.log';
              $message = date('Y-m-d H:i:s') ." " ."[Get categories from woocoomerce]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
              error_log($message, 3, $pluginlog);        
          } 


add_action ('Cron_categories_from_woo', 'get_categories_from_woo');
?>