<?php

function get_api_jobs()
{
$api = get_option('robolabs_api_code');
$endpoint = get_option('server_url');
$main_body_array = get_option('orders_error');
$successfull_orders = get_option('successfull_orders');
foreach($main_body_array as $body1)
    {
        $logs = json_decode($body1, true);
        $id = $logs['id'];
        $api_job_id = $logs['result']['data']['api_job_id'];
        $data_api = array(
        'secret' => $api,
        'api_job_id' => $api_job_id,
        );
        $ch = curl_init();
    
        curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/get_api_job");
    
        curl_setopt($ch, CURLOPT_POST, 1);
    
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api));
        
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
    
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        
    
        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        // ...
      
        $response = curl_exec($ch);
    
        // Then, after your curl_exec call:
        $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $header = substr($response, 0, $header_size);
        $body = substr($response, $header_size); 
                                                        
        curl_close ($ch);
        
        $robo_response = json_decode($body , true);
        $state = $robo_response['result']['data']['state'];
        if($state == "Vykdymas nepavyko")
        {
                $logs['result']['status_code'] = 500;
                $logs['result']['error'] = "Unable to sync";
                $body2 = json_encode($logs);
                $body_array[] = $body2;
                
        }
        
        
        
        $pluginlog = plugin_dir_path(__FILE__).'debug.log';
        $message = date('Y-m-d H:i:s') ." " ."[Get jobs from robo]". "   " . " $state " .PHP_EOL;
        error_log($message, 3, $pluginlog);
        
    }
update_option('orders_error' , $body_array , $autoload = 'yes');
    
}
add_action ('Cron_jobs_from_robo', 'get_api_jobs');