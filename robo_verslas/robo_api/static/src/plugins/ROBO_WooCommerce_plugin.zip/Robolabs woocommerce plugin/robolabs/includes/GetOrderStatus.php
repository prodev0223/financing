<?php 


function get_orders_status(){

      $robolabs_date_from_orders = get_option('robolabs_date_from');
      $journal_series =  get_option('journal_series');
      $successfull_orders = get_option('successfull_orders');
      
       $args = array(
    'limit' => -1,
    'date_created' => '>='.strtotime($robolabs_date_from_orders),
    'return' => 'ids',
    'exclude' => $successfull_orders,
);

$order_id_list = wc_get_orders($args);

          
                    if($order_id_list) 
                      { 

                          $api = get_option('robolabs_api_code');
                          $endpoint = get_option('server_url');
                          foreach($order_id_list as $orderid)
                          {                             
                          
                          
                          $order_data = array(

                                  'secret' => $api,
                                  'invoice_number' => $journal_series . $orderid,
                              );
                              
                                  
                                  if($successfull_orders)
                                  {
                                        if(!in_array($orderid, $successfull_orders))
                                        {
                                    // send API request via cURL
                              
                                      $ch = curl_init();

                                      curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/get_invoice");
                              
                                      curl_setopt($ch, CURLOPT_POST, 1);
                              
                                      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
                                      
                                      curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                              
                                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                      
                                      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                                      
         
                                      curl_setopt($ch, CURLOPT_VERBOSE, 1);
                                      curl_setopt($ch, CURLOPT_HEADER, 1);
                                      // ...
                                    
                                      $response = curl_exec($ch);

                                      // Then, after your curl_exec call:
                                      $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                                      $header = substr($response, 0, $header_size);
                                      $body = substr($response, $header_size); 
                                                                                      
                                      curl_close ($ch);    
                                        }       
                                  }

                                                 
							          if($body) 
                                      {     
                                      $logs = json_decode($body, true);
                                      $status_code = $logs['result']['status_code'];
                                      $error = $logs['result']['error']; 
                                      $pluginlog = plugin_dir_path(__FILE__).'debug.log';
                                      $message = date('Y-m-d H:i:s') ." " ."[Get orders status from robo]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
                                      error_log($message, 3, $pluginlog);
                                      if($error == "Invoice was found in the system.")
                                      {
                                      array_push($successfull_orders, $orderid);
                                      }
                                      }
                                      $body = null;
                                     
                                      update_option('successfull_orders' , $successfull_orders); 
                                    
                             }     
                          }   
   
           }
          
add_action ('Cron_orders_status', 'get_orders_status');