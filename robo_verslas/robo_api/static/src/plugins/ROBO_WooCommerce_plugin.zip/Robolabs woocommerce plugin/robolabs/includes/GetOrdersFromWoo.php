<?php 


function get_orders_from_woo(){

      $robolabs_date_from_orders = get_option('robolabs_date_from');
      $journal_series =  get_option('journal_series');
      $orderstatus = get_option('Orderstatus');
      $api = get_option('robolabs_api_code');
      $endpoint = get_option('server_url');
      $currentDateTime = date('Y-m-d H:i:s');
      $successfull_orders = get_option('successfull_orders');
      
       $args = array(
    'status' => $orderstatus,
    'limit' => -1,
    'date_created' => '>='.strtotime($robolabs_date_from_orders),
    'return' => 'ids',
    'exclude' => $successfull_orders,
    
);


$order_id_list = wc_get_orders($args);


  $data_api_product = array(
      'secret' => $api,
      'date_from' => "2000-01-01 0:00:00",
      'date_to' =>  $currentDateTime,
      'data_type' => "modify",
      'execute_immediately' => true,
      );
              // send API request via cURL

        $ch = curl_init();
        
        
        curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/new_products");

        curl_setopt($ch, CURLOPT_POST, 1);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api_product));
        
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        

        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        // ...
      
        $responsep = curl_exec($ch);

        // Then, after your curl_exec call:
        $header_sizep = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headerp = substr($responsep, 0, $header_sizep);
        $bodyp = substr($responsep, $header_sizep);                                               
        curl_close ($ch);
        
        $productsp = json_decode($bodyp, true);


          
                    if($order_id_list) 
                      { 

                          $ch = curl_init();
                          $body_array = array();
                          foreach($order_id_list as $order_id)
                          {

                          $order = wc_get_order( $order_id );                  
                          
                          if($order->get_total() > 0)
                          {
                                      
                                          if ($order->get_billing_company() && get_post_meta( $order->get_id(), '_company_code', true ))
                                          {
                                              $company = true;
                                              $partnername = $order->get_billing_company();
											  $company_vat_code = get_post_meta( $order->get_id(), '_VAT_number', true );
											  if(!$company_vat_code)
											  {
												  $company_vat_code = "-";
											  }
                                          }
                                          else                  
                                          {
                                              $company = false;
                                              $partnername = $order->get_formatted_billing_full_name();
                                              $company_vat_code = "-";
                                          }
                                          
                                          
                                          
                                          $item = (array) null;
                                          foreach ( $order->get_items() as $item_id => $item )
                                          {    
                                            $product = $item->get_product();
                                            $product_id = $item->get_product_id();
											  if($product)
											  {
												  $sku = $product->get_sku();
												  $description = $product->get_description();
												  
												 if ($product-> is_virtual('yes')) 
                                                {
                                                    $type = "service";
                                                }
                                                else
                                                {
                                                    $type = "product";
                                                }  
											  }
											  else 
											  {
												$description = "-";  
											  }
                                            $name = $item->get_name();
                                            



                                            $quantity = $item->get_quantity();
                                            $eustates = array(
                                                  	'AT',
                                                  	'BE',
                                                  	'BG',
                                                  	'CY',
                                                  	'CZ',
                                                  	'DE',
                                                  	'DK',
                                                  	'EE',
                                                  	'ES',
                                                  	'FI',
                                                  	'FR',
                                                  	'GB',
                                                  	'GR',
                                                  	'HR',
                                                  	'HU',
                                                  	'IE',
                                                  	'IT',
                                                  	'LU',
                                                  	'LV',
                                                  	'MT',
                                                  	'NL',
                                                  	'PL',
                                                  	'PT',
                                                  	'RO',
                                                  	'SE',
                                                  	'SI',
                                                  	'SK',
                                                  	'IM',
                                                  	'MC'
                                                );
                                            $country = $order->get_billing_country();
                                            
                                            // Tax rate calculator
                                            $total_sum = $item->get_total();
                                            $taxes_sum = $item->get_total_tax();
                                            $price = $total_sum / $quantity;
                                            
                                            if($product)
											{
												$tax_rates = WC_Tax::get_rates( $product->get_tax_class() );
												if (!empty($tax_rates)) {
                                                $tax_rate1 = reset($tax_rates);
                                                $tax_rate = $tax_rate1['rate'];
                                                }
                                                else
                                                {
                                                 $tax_rate = 0;
                                                }
											}
											else 
											  {

													$tax_rate1 = $taxes_sum * 100 / $total_sum;
													$tax_rate = round($tax_rate1);
											  }
                                            

                                                                                                                                                                                                                            
                                            if($tax_rate == 21)
                                            {
                                                $vat = "PVM1";
                                                
                                            }
                                            elseif($tax_rate == 9)
                                            {
                                                $vat = "PVM2";
                                            }
                                            elseif($tax_rate == 5)
                                            {
                                                $vat = "PVM3";
                                            }
                                            elseif($tax_rate == 0)
                                            {
                                            foreach($eustates as $state)
                                                {   
                                                    if($state == $country && $country != "LT")
                                                    {   
                                                            $vat = "PVM13";
                                                    }
                                                    elseif($state !== $country && $country != "LT")
                                                    {   
                                                            $vat = "PVM12";
                                                    }
                                                    elseif($country == "LT")
                                                    {
                                                            $vat = "PVM5";
                                                    }
                                                    elseif($state == $country && $country != "LT" && $type == "service")
                                                    {   
                                                            $vat = "PVM15";
                                                    }
                                                }
                                                
                                            }
											  
											if(in_array($country, $eustates))
											{
												$vat = "PVM13";
											}
                                            
                                            foreach($productsp['result']['data'] as $roboproduct)
                                            {
                                            $robocode = $roboproduct['code'];
                                            if($robocode == $sku)
                                                {
                                                 $product_id_robo = $roboproduct['product_id'];
                                                }
                                            }
                                            
                                            
                                                                                         
                                            $product_array[] = array (
                                            
                                                'product' => $name,
                                                'product_code' => $sku,
                                                'description' => $description,
                                                'price' => $price,
                                                'qty' => $quantity,
                                                'vat_code' => $vat,
                                                'vat' =>  (float)$taxes_sum,
                                            ); 
                                          }
                                          if($order->get_shipping_total() > 0)
                                          { 

											if(in_array($country, $eustates))
											{
													$vat_shipping = "PVM13";
													$shipping_total_tax = 0;
											}
											else
											{
												  $shipping_total = $order->get_shipping_total();
                                                  $shipping_total_tax = $shipping_total * 0.21;
												  $vat_shipping = "PVM1";
											}
													 
                                                
                                                $product_array[] = array (
                                                  'product' => "Shipping",
                                                  'price' =>  $shipping_total,
                                                  'qty' => 1,
                                                  'vat_code' => $vat_shipping,
                                                  'vat' => $shipping_total_tax,
                                                  'product_code' => "Shipping",
                                                );
                                          }
                                          foreach( $order->get_coupon_codes() as $coupon_code ){

                                        $coupon_post_obj = get_page_by_title($coupon_code, OBJECT, 'shop_coupon');                                                                   
                                        $coupon_id       = $coupon_post_obj->ID;
                                        $coupon = new WC_Coupon($coupon_id);
                                        if ( $coupon->get_discount_type() == 'fixed_cart' ){
                                            $coupon_name = $coupon->get_code();
                                            $coupon_description = $coupon->get_description();
                                             $product_array[] = array (
                                                  'product' => $coupon_name,
                                                  'price' =>  0,
                                                  'qty' => 1,
                                                  'vat_code' => "PVM1",
                                                  'description' => $coupon_description,
                                                  'vat' => 0,
                                                  'product_code' => "Coupon",
                                                );
                                        }
                                        if ( $coupon->get_discount_type() == 'fixed_product' )
                                        {
                                            $coupon_name = $coupon->get_code();
                                            $coupon_description = $coupon->get_description();
                                            $product_array[] = array (
                                                  'product' => $coupon_name,
                                                  'price' =>  0,
                                                  'qty' => 1,
                                                  'vat_code' => "PVM1",
                                                  'description' => $coupon_description,
                                                  'vat' => 0,
                                                  'product_code' => "Coupon",
                                                );
                                        }
                                        if ( $coupon->get_discount_type() == 'percent' )
                                        {
                                            $coupon_name = $coupon->get_code();
                                            $coupon_description = $coupon->get_description();
                                            $product_array[] = array (
                                                  'product' => $coupon_name,
                                                  'price' =>  0,
                                                  'qty' => 1,
                                                  'vat_code' => "PVM1",
                                                  'description' => $coupon_description,
                                                  'vat' => 0,
                                                  'product_code' => "Coupon",
                                                );
                                        }
                                    
                                    }
                                    
                                    if($order->get_fees())
                                    {
                                      $fees = $order->get_fees();
                                        foreach($fees as $fee)
                                        {
                                              $fee_name = $fee['name'];
                                              $fee_id = $fee['id'];
                                              $fee_tax_class = $fee['tax_class'];
                                              $fee_amount = $fee['amount'];
                                              $fee_total = $fee['total'];
                                              $fee_total_tax = $fee['total_tax'];
                                              	$tax_rates_fee = WC_Tax::get_rates( $fee_tax_class );
												if (!empty($tax_rates_fee)) {
                                                $tax_rate1 = reset($tax_rates_fee);
                                                $tax_rate = $tax_rate1['rate'];
                                                }
                                                else
                                                {
                                                 $tax_rate = 0;
                                                }
                                                
                                                if($tax_rate == 21)
                                                {
                                                    $vat = "PVM1";
                                                    
                                                }
                                                elseif($tax_rate == 9)
                                                {
                                                    $vat = "PVM2";
                                                }
                                                elseif($tax_rate == 5)
                                                {
                                                    $vat = "PVM3";
                                                }
                                                elseif($tax_rate == 0)
                                                {
                                                foreach($eustates as $state)
                                                    {   
                                                        if($state == $country && $country != "LT")
                                                        {   
                                                                $vat = "PVM13";
                                                        }
                                                        elseif($state !== $country && $country != "LT")
                                                        {   
                                                                $vat = "PVM12";
                                                        }
                                                        elseif($country == "LT")
                                                        {
                                                                $vat = "PVM5";
                                                        }
                                                        elseif($state == $country && $country != "LT" && $type == "service")
                                                        {   
                                                                $vat = "PVM15";
                                                        }
                                                    }
                                                    
                                                }
											
											if(in_array($country, $eustates))
											{
												$vat = "PVM13";
											}
											
                                            $product_array[] = array (
                                                  'product' => $fee_name,
                                                  'price' =>  $fee_amount,
                                                  'qty' => 1,
                                                  'vat_code' => $vat,
                                                  'vat' => $fee_total_tax,
                                                  'product_code' => $fee_name . $fee_id,
                                                );                                                
                                                                                                
                                        }                                    
                                    }
                                    
                          if($order->get_date_completed())
                          {
                          $order_date = $order->get_date_completed()->format ('Y-m-d');
                          }
                          else
                          {
                          $order_date = $order->get_date_created()->format ('Y-m-d');
                          }
                                    
                                                      
                          $order_data = array(
                                  'secret' => $api,
                                  'journal' => $journal_series,
                                  'date_invoice' => $order_date,
                                  'due_date' => $order_date,
                                  'number' => $journal_series . $order->get_id(),
                                  'currency' => $order->get_currency(),
                                  'force_type' => "out_invoice",
                      
                                  'partner' =>
                                    array(
                                          
                                          'name' => $partnername,
                                          'is_company' => $company,
                                          'company_code' => get_post_meta( $order->get_id(), '_company_code', true ),
                                          'vat_code' => $company_vat_code,
                                          'street' => $order->get_billing_address_1(). " " .$order->get_billing_address_2(),
                                          'city' => $order->get_billing_city(),
                                          'zip' => $order->get_billing_postcode(),
                                          'country' => $country,
                                          'phone' => $order->get_billing_phone(),
                                          'email' => $order->get_billing_email(),

                                   ),
                                    'invoice_lines' =>
                                   
                                   
                                            $product_array,
                                  
                                  
                                  'payments' =>
                                   array
                                  ( 
                                            array (
                                       'payer' => $partnername,
                                       'amount' => (float)$order->get_total(),
                                       'date' => $order_date,                                       
                                       ),
                                  ),

                              );
                              
                              
                                       
							          
                                        if(!in_array($order->get_id(), $successfull_orders))
                                        {
										
										//echo json_encode($order_data);
                                    // send API request via cURL
                              

                                      curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/create_invoice");
                              
                                      curl_setopt($ch, CURLOPT_POST, 1);
                              
                                      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
                                      
                                      curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                              
                                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                      
                                      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                                      
         
                                      curl_setopt($ch, CURLOPT_VERBOSE, 1);
                                      curl_setopt($ch, CURLOPT_HEADER, 1);
                                      // ...
                                    
                                      $response = curl_exec($ch);
											

                                      // Then, after your curl_exec call:
                                      $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                                      $header = substr($response, 0, $header_size);
                                      $body = substr($response, $header_size);
											
									
                                          
                                      $body1 = json_decode($body, true);
                                      $body1['id'] =  $order->get_id();                               
                                      $body2 = json_encode($body1);
							          $body_array[] = $body2;
                                      
                                         
                                        }
                                  


                                      
                                     
                                      $product_array = (array) null;
                                      $vat = null;
                                      $shipvat = null;
                                      
                                                 
							          if($body) 
                                      {     
                                      $logs = json_decode($body, true);
                                      $status_code = $logs['result']['status_code'];
                                      $error = $logs['result']['error']; 
                                      $pluginlog = plugin_dir_path(__FILE__).'debug.log';
                                      $message = date('Y-m-d H:i:s') ." " ."[Get orders from woocoomerce]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
                                      error_log($message, 3, $pluginlog);
                                      }
                                      $body = null;
                                      
                                      
                                      
                             }
                             
                                
                           }
                           
                           curl_close ($ch);
                          }
                     update_option('orders_error' , $body_array , $autoload = 'yes');          
           }
          
add_action ('Cron_orders_from_woo', 'get_orders_from_woo');