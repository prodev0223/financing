<?php 


function get_orders_refund(){

            $robolabs_date_from_orders = get_option('robolabs_date_from');
            $successfull_orders = get_option('successfull_orders');
            $args = array(
                'type' => 'shop_order_refund',
                'date_created' => '>='.strtotime($robolabs_date_from_orders),
                'limit' => -1,
                'exclude' => $successfull_orders,
            );
            $refunds = wc_get_orders( $args );
            $api = get_option('robolabs_api_code');
            $endpoint = get_option('server_url');
            $journal_series =  get_option('journal_series');
            $robowarehouse =  get_option('robowarehouse');
            
            
$data_api_product = array(
      'secret' => $api,
      'warehouse' => $robowarehouse,
      'execute_immediately' => true,
      );
              // send API request via cURL

        $ch = curl_init();
        
        
        curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/products");

        curl_setopt($ch, CURLOPT_POST, 1);

        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api_product));
        
        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        

        curl_setopt($ch, CURLOPT_VERBOSE, 1);
        curl_setopt($ch, CURLOPT_HEADER, 1);
        // ...
      
        $responsep = curl_exec($ch);

        // Then, after your curl_exec call:
        $header_sizep = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
        $headerp = substr($responsep, 0, $header_sizep);
        $bodyp = substr($responsep, $header_sizep);                                               
        curl_close ($ch);
        

        $productsp = json_decode($bodyp, true);            
            
            
            
            foreach($refunds as $refund)
                {
                    
                    $refund_parent_id = $refund -> get_parent_id();
                    $refund_id = $refund -> get_id();
                    $refund_date = $refund -> get_date_created()->format ('Y-m-d');
                    $refund_total = $refund -> get_total() * (-1);
                    $order = wc_get_order($refund_parent_id);

                     
                                          if ($order->get_billing_company() && get_post_meta( $order->get_id(), '_company_code', true ))
                                          {
                                              $company = true;
                                              $partnername = $order->get_billing_company();
											  $company_vat_code = get_post_meta( $order->get_id(), '_VAT_number', true );
											  if(!$company_vat_code)
											  {
												  $company_vat_code = "-";
											  }
                                          }
                                          else                  
                                          {
                                              $company = false;
                                              $partnername = $order->get_formatted_billing_full_name();
                                              $company_vat_code = "-";
                                          }
                      
                     $item = (array) null; 
                    if( $refund->get_items() )
                    {
                    foreach( $refund->get_items() as $item_id => $item )
                    {
                    

                                  $name       = $item->get_name();
                                  $product_id    = $item->get_id();
                                  $product = $item->get_product();
                                  $quantityminus = $item->get_quantity();
                                  $quantity = $quantityminus * (-1);
                                   	if($product)
											  {
												  $sku = $product->get_sku();
												  $description = $product->get_description();
												  
												 if ($product-> is_virtual('yes')) 
                                                {
                                                    $type = "service";
                                                }
                                                else
                                                {
                                                    $type = "product";
                                                }  
											  }
											  else 
											  {
												$description = "-";  
											  }
                                  
                                  $eustates = array(
                                                  	'AT',
                                                  	'BE',
                                                  	'BG',
                                                  	'CY',
                                                  	'CZ',
                                                  	'DE',
                                                  	'DK',
                                                  	'EE',
                                                  	'ES',
                                                  	'FI',
                                                  	'FR',
                                                  	'GB',
                                                  	'GR',
                                                  	'HR',
                                                  	'HU',
                                                  	'IE',
                                                  	'IT',
                                                  	'LU',
                                                  	'LV',
                                                  	'MT',
                                                  	'NL',
                                                  	'PL',
                                                  	'PT',
                                                  	'RO',
                                                  	'SE',
                                                  	'SI',
                                                  	'SK',
                                                  	'IM',
                                                  	'MC'
                                                );
                                            $country = $order->get_billing_country();
                                            
                                            
                                            $total_sum = $item->get_total();
                                            $taxes_sum = $item->get_total_tax();
                                            $price1 = $total_sum / $quantity;
                                            $price = $price1 * (-1);
                                            
                                            if($product)
											{
												$tax_rates = WC_Tax::get_rates( $product->get_tax_class() );
												if (!empty($tax_rates)) {
                                                $tax_rate1 = reset($tax_rates);
                                                $tax_rate = $tax_rate1['rate'];
                                                }
                                                else
                                                {
                                                 $tax_rate = 0;
                                                }
											}
											else 
											  {

													$tax_rate1 = $taxes_sum * 100 / $total_sum;
													$tax_rate = round($tax_rate1);
											  }
                                            if($tax_rate == 21)
                                            {
                                                $vat = "PVM1";
                                                
                                            }
                                            elseif($tax_rate == 9)
                                            {
                                                $vat = "PVM2";
                                            }
                                            elseif($tax_rate == 5)
                                            {
                                                $vat = "PVM3";
                                            }
                                            elseif($tax_rate == 0)
                                            {
                                            foreach($eustates as $state)
                                                {   
                                                    if($state == $country && $country != "LT")
                                                    {   
                                                            $vat = "PVM13";
                                                    }
                                                    elseif($state !== $country && $country != "LT")
                                                    {   
                                                            $vat = "PVM12";
                                                    }
                                                    elseif($country == "LT")
                                                    {
                                                            $vat = "PVM5";
                                                    }
                                                    elseif($state == $country && $country != "LT" && $type == "service")
                                                    {   
                                                            $vat = "PVM15";
                                                    }
                                                }
                                                
                                            }
                                            
                                            
                                            
                                            foreach($productsp["result"]["data"] as $roboproduct)
                                            {
                                            $roboname = $roboproduct['name'];
                                            if($roboname == $name)
                                                {
                                                 $product_id_robo = $roboproduct['product_id'];
                                                }
                                            }
                                        
                                   
                                      $product_array[] = array (
                                            
                                                'product' => $name,
                                                'product_id' => (int)$product_id_robo,
                                                'product_code' => $sku,
                                                'description' => $description,
                                                'price' => (float)$price,
                                                'qty' => $quantity,
                                                'vat_code' => $vat,
                                                'vat' =>  (float)$taxes_sum * (-1),

                                            );
                                      
                              }    
                            }
                            else
                            {
                            
                             if($refund_total == $order->get_total())
                             {
                             foreach ( $order->get_items() as $item_id => $item )
                                          {    
                                            $product = $item->get_product();
                                            $product_id = $item->get_product_id();
                                            $name = $item->get_name();
                                            if($product)
											  {
												  $sku = $product->get_sku();
												  $description = $product->get_description();
												  
												 if ($product-> is_virtual('yes')) 
                                                {
                                                    $type = "service";
                                                }
                                                else
                                                {
                                                    $type = "product";
                                                }  
											  }
											  else 
											  {
												$description = "-";  
											  }


                                            $quantity = $item->get_quantity();
                                            $eustates = array(
                                                  	'AT',
                                                  	'BE',
                                                  	'BG',
                                                  	'CY',
                                                  	'CZ',
                                                  	'DE',
                                                  	'DK',
                                                  	'EE',
                                                  	'ES',
                                                  	'FI',
                                                  	'FR',
                                                  	'GB',
                                                  	'GR',
                                                  	'HR',
                                                  	'HU',
                                                  	'IE',
                                                  	'IT',
                                                  	'LU',
                                                  	'LV',
                                                  	'MT',
                                                  	'NL',
                                                  	'PL',
                                                  	'PT',
                                                  	'RO',
                                                  	'SE',
                                                  	'SI',
                                                  	'SK',
                                                  	'IM',
                                                  	'MC'
                                                );
                                            $country = $order->get_billing_country();
                                            
                                            // Tax rate calculator
                                            $total_sum = $item->get_total();
                                            $taxes_sum = $item->get_total_tax();
                                            $price = $total_sum / $quantity;
                                            
                                            if($product)
											{
												$tax_rates = WC_Tax::get_rates( $product->get_tax_class() );
												if (!empty($tax_rates)) {
                                                $tax_rate1 = reset($tax_rates);
                                                $tax_rate = $tax_rate1['rate'];
                                                }
                                                else
                                                {
                                                 $tax_rate = 0;
                                                }
											}
											else 
											  {

													$tax_rate1 = $taxes_sum * 100 / $total_sum;
													$tax_rate = round($tax_rate1);
											  }                                                                                                                                                                               
                                            if($tax_rate == 21)
                                            {
                                                $vat = "PVM1";
                                                
                                            }
                                            elseif($tax_rate == 9)
                                            {
                                                $vat = "PVM2";
                                            }
                                            elseif($tax_rate == 5)
                                            {
                                                $vat = "PVM3";
                                            }
                                            elseif($tax_rate == 0)
                                            {
                                            foreach($eustates as $state)
                                                {   
                                                    if($state == $country && $country != "LT")
                                                    {   
                                                            $vat = "PVM13";
                                                    }
                                                    elseif($state !== $country && $country != "LT")
                                                    {   
                                                            $vat = "PVM12";
                                                    }
                                                    elseif($country == "LT")
                                                    {
                                                            $vat = "PVM5";
                                                    }
                                                    elseif($state == $country && $country != "LT" && $type == "service")
                                                    {   
                                                            $vat = "PVM15";
                                                    }
                                                }
                                                
                                            }
                                            
                                            foreach($productsp["result"]["data"] as $roboproduct)
                                            {
                                            $roboname = $roboproduct['name'];
                                            if($roboname == $name)
                                                {
                                                 $product_id_robo = $roboproduct['product_id'];
                                                }
                                            }
                                            
                                                                                         
                                            $product_array[] = array (
                                            
                                                'product' => $name,
                                                'product_id' => $product_id_robo,
                                                'product_code' => $sku,
                                                'description' => $description,
                                                'price' => $price,
                                                'qty' => $quantity,
                                                'vat_code' => $vat,
                                                'vat' =>  (float)$taxes_sum,
                                            ); 
                                          }
                                          
                                          }
                                          else
                                          {
                                          $product_array[] = array (
                                            
                                                'product' => "Pinigu gra�inimas",
                                                'price' => $refund_total,
                                                'qty' => 1,
                                                'vat_code' => "PVM5",
                                                );
                                          }
                                          
                                                 
                            }
                            
                            if($refund->get_shipping_total() < 0)
                                          { 
                                                
                                                
                                               $shipping_total_tax = 0;
                                                    foreach( $order->get_items( 'shipping' ) as $item_id => $shipping_item_obj ){

                                                        $shipping_method_taxes = $shipping_item_obj->get_taxes();
                                                        $shippingtax = $shipping_method_taxes['total'];
														if($shippingtax)
														{
                                                        $values = array_values( $shippingtax);
                                                        $shipping_total_tax = $values[0];
														}
                                                    }
                                                    if($shipping_total_tax != 0)
                                                     {
                                                      $shipping_total = $refund->get_shipping_total() * (-1);
                                                      $shipping_tax_rate1 =  $shipping_total_tax * 100 / $shipping_total;
                                                      $shipping_tax_rate = round($shipping_tax_rate1);
                                                    }
                                                    else
                                                    {
                                                     $shipping_total_tax = 0;
                                                     $shipping_tax_rate = 0;
													 $shipping_total = $refund->get_shipping_total() * (-1);
                                                    }
                                                  if($shipping_tax_rate == 21)
                                                  {
                                                      $shipvat = "PVM1";
                                                      
                                                  }
                                                  elseif($shipping_tax_rate == 9)
                                                  {
                                                      $shipvat = "PVM2";
                                                  }
                                                  elseif($shipping_tax_rate == 5)
                                                  {
                                                      $shipvat = "PVM3";
                                                  }
                                                  elseif($shipping_tax_rate == 0)
                                                  {
                                                  foreach($eustates as $state)
                                                      {   
                                                          if($state == $country && $country != "LT")
                                                          {   
                                                                  $shipvat = "PVM13";
                                                          }
                                                          elseif($state !== $country && $country != "LT")
                                                          {   
                                                                  $shipvat = "PVM12";
                                                          }
                                                          elseif($country == "LT")
                                                          {
                                                                  $shipvat = "PVM5";
                                                          }
                                                      }
                                                      
                                                  }
                                                
                                                $product_array[] = array (
                                                  'product' => "Shipping",
                                                  'product_id' => "Shipping-" . $refund->get_shipping_method(),
                                                  'price' =>  $shipping_total,
                                                  'qty' => 1,
                                                  'vat_code' => $shipvat,
                                                  'vat' => $shipping_total_tax ,
                                                );
                                          }
                                          
                                    if($order->get_fees())
                                    {
                                      $fees = $order->get_fees();
                                        foreach($fees as $fee)
                                        {
                                              $fee_name = $fee['name'];
                                              $fee_id = $fee['id'];
                                              $fee_tax_class = $fee['tax_class'];
                                              $fee_amount = $fee['amount'];
                                              $fee_total = $fee['total'];
                                              $fee_total_tax = $fee['total_tax'];
                                              	$tax_rates_fee = WC_Tax::get_rates( $fee_tax_class );
												if (!empty($tax_rates_fee)) {
                                                $tax_rate1 = reset($tax_rates_fee);
                                                $tax_rate = $tax_rate1['rate'];
                                                }
                                                else
                                                {
                                                 $tax_rate = 0;
                                                }
                                                
                                                if($tax_rate == 21)
                                                {
                                                    $vat = "PVM1";
                                                    
                                                }
                                                elseif($tax_rate == 9)
                                                {
                                                    $vat = "PVM2";
                                                }
                                                elseif($tax_rate == 5)
                                                {
                                                    $vat = "PVM3";
                                                }
                                                elseif($tax_rate == 0)
                                                {
                                                foreach($eustates as $state)
                                                    {   
                                                        if($state == $country && $country != "LT")
                                                        {   
                                                                $vat = "PVM13";
                                                        }
                                                        elseif($state !== $country && $country != "LT")
                                                        {   
                                                                $vat = "PVM12";
                                                        }
                                                        elseif($country == "LT")
                                                        {
                                                                $vat = "PVM5";
                                                        }
                                                        elseif($state == $country && $country != "LT" && $type == "service")
                                                        {   
                                                                $vat = "PVM15";
                                                        }
                                                    }
                                                    
                                                }
                                            $product_array[] = array (
                                                  'product' => $fee_name,
                                                  'price' =>  $fee_amount,
                                                  'qty' => 1,
                                                  'vat_code' => $vat,
                                                  'vat' => $fee_total_tax,
                                                  'product_code' => $fee_name . $fee_id,
                                                );                                                
                                                                                                
                                        }                                    
                                    }
                            
                    $order_data = array(

                                  'secret' => $api,
                                  'journal' => $journal_series,
                                  'date_invoice' => $refund_date,
                                  'due_date' => $refund_date,
                                  'number' => $journal_series . "-R-" . $refund_id,
                                  'currency' => $order->get_currency(),
                                  'force_type' => "out_refund",
                      
                                  'partner' =>
                                    array(
                                          
                                          'name' => $partnername,
                                          'is_company' => $company,
                                          'company_code' => get_post_meta( $order->get_id(), '_company_code', true ),
                                          'vat_code' => $company_vat_code,
                                          'street' => $order->get_billing_address_1(). " " .$order->get_billing_address_2(),
                                          'city' => $order->get_billing_city(),
                                          'zip' => $order->get_billing_postcode(),
                                          'country' => $country,
                                          'phone' => $order->get_billing_phone(),
                                          'email' => $order->get_billing_email(),

                                   ),
                                    'invoice_lines' =>
                                   
                                   
                                            $product_array,
                                  
                                          
                                  'payments' =>
                                   array
                                  ( 
                                            array (
                                       'payer' => $partnername,
                                       'amount' => $refund_total,
                                       'date' => $refund_date,
                                       ),
                                  ),

                              );
                                      
                                      
                                    
                                        if(!in_array($refund_id, $successfull_orders))
                                        {  
                                         
                                      $ch = curl_init();
                                      
                                      
                                      curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/create_invoice");
                              
                                      curl_setopt($ch, CURLOPT_POST, 1);
                              
                                      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
                                      
                                      curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                              
                                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                      
                                      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                                      
         
                                      curl_setopt($ch, CURLOPT_VERBOSE, 1);
                                      curl_setopt($ch, CURLOPT_HEADER, 1);
                                      // ...
                                    
                                      $response = curl_exec($ch);

                                      // Then, after your curl_exec call:
                                      $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                                      $header = substr($response, 0, $header_size);
                                      $body = substr($response, $header_size); 
                                                                                      
                                      curl_close ($ch);
                                       
                       
                      $product_array = (array) null;
                      $logs = json_decode($body, true);
                      $status_code = $logs['result']['status_code'];
                      $error = $logs['result']['error']; 
                      $pluginlog = plugin_dir_path(__FILE__).'debug.log';
                      $message = date('Y-m-d H:i:s') ." " ."[Get orders refund]". "ID" . " $refund_id  " . "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
                      error_log($message, 3, $pluginlog);   
                                      }     
                }      

           }
          
add_action ('Cron_orders_refund', 'get_orders_refund');