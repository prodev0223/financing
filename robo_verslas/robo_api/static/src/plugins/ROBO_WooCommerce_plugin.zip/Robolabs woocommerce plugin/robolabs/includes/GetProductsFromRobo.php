<?php 


function get_products_from_robo(){

                                $api = get_option('robolabs_api_code');
                                $endpoint = get_option('server_url');
                                $robowarehouse =  get_option('robowarehouse');
                                $product_quantity = get_option('ProductQuantity');
                                $data_api = array(
                                    'secret' => $api,
                                    'warehouse' => $robowarehouse,
                                    'execute_immediately' => true,
                                    );
                                            // send API request via cURL
                              
                                      $ch = curl_init();
                                      
                                      
                                      curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/products");
                              
                                      curl_setopt($ch, CURLOPT_POST, 1);
                              
                                      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api));
                                      
                                      curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                              
                                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                      
                                      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                                      
         
                                      curl_setopt($ch, CURLOPT_VERBOSE, 1);
                                      curl_setopt($ch, CURLOPT_HEADER, 1);
                                      // ...
                                    
                                      $response = curl_exec($ch);

                                      // Then, after your curl_exec call:
                                      $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                                      $header = substr($response, 0, $header_size);
                                      $body = substr($response, $header_size);                                               
                                      curl_close ($ch);
                                    
                                      
                                      
                                      $products = json_decode($body, true);
                                      
                                      foreach ($products["result"]["data"] as $produktu_masyvas)
                                            {
                                                                              
                                              $variantukiekis = 0;
                                              $code_sku = $produktu_masyvas['code'];
                                              $name = $produktu_masyvas['name'];
                                              $price = $produktu_masyvas['public_price'];
                                              $qty_on_hand = $produktu_masyvas['qty_on_hand'];
										  
										  
										  if(isset($code_sku))
										    {
                                              
                                              $post_id = wc_get_product_id_by_sku($code_sku);
										  
                                              if(!isset($post_id) or $post_id == 0)
                                              {
                                                   $argsv = array(
                                                          'posts_per_page'     => -1,
                                                          'post_type'          => 'product_variation',
                                                          'suppress_filters'   => true
                                                      );
                                                  
                                                      $posts_array = get_posts( $argsv );
                                                       
                                                      foreach ( $posts_array as $post_array ) 
                                                      {
                                                          $skucode = get_post_meta( $post_array->ID, '_sku', true );
                                                          if($skucode == $code_sku)
                                                          {
                                                          
                                                             if($product_quantity == 'Taip')
                                                             {
                                                             
                                                             if($qty_on_hand == 0)
                                                              {
                                                                 $out_of_stock_staus = 'outofstock';
                                                                 wc_update_product_stock($post_array->ID, $qty_on_hand, 'set' ,  true);
                                                                 update_post_meta( $post_array->ID, '_stock_status', wc_clean( $out_of_stock_staus ) );
                                                                 wp_set_post_terms( $post_array->ID, 'outofstock', 'product_visibility', true );
                                                                 wc_delete_product_transients( $post_array->ID ); 
                                                              }
                                                              else
                                                              {
                                                                  update_post_meta( $post_array->ID, '_manage_stock', "yes");  
                                                                  $in_stock_staus = 'instock';
                                                                  wc_update_product_stock($post_array->ID, $qty_on_hand, 'set' ,  true);
                                                                  update_post_meta( $post_array->ID, '_stock_status', wc_clean( $in_stock_staus ) );
                                                                  wp_set_post_terms( $post_array->ID, 'instock', 'product_visibility', true );
                                                                  wc_delete_product_transients( $post_array->ID ); 
                                                              }
                                                            }
                                                              $product = wc_get_product( $post_array->ID );
                                                              $product->set_regular_price($price);
                                                              $product->save(); 
                                                              
                                                              
                                                              $variantukiekis = 1;
                                                          }                                                  
                                                      }
                                                if($variantukiekis == 0)
                                                {
                                                  $args = array(	   
                                                        	'post_author' => 1, 
                                                        	'post_content' => '',
                                                        	'post_status' => "draft", // (Draft | Pending | Publish)
                                                        	'post_title' => $name,
                                                        	'post_parent' => '',
                                                        	'post_type' => "product"
                                                        ); 
                                                        
                                                        // Create a simple WooCommerce product
                                                        $post_id = wp_insert_post( $args );
                                                        
                                                        
                                                        wp_set_object_terms( $post_id, 'simple', 'product_type' );                                                        
                                                        update_post_meta( $post_id, '_sku', $code_sku );
                                                        
                                                        if($product_quantity == 'Taip')
                                                        {
                                                        if($qty_on_hand == 0)
                                                        {
                                                           $out_of_stock_staus = 'outofstock';
                                                           wc_update_product_stock($post_id, $qty_on_hand, 'set' ,  true);
                                                           update_post_meta( $post_id, '_stock_status', wc_clean( $out_of_stock_staus ) );
                                                           wp_set_post_terms( $post_id, 'outofstock', 'product_visibility', true );
                                                           wc_delete_product_transients( $post_id ); 
                                                        }
                                                        else
                                                        {
                                                            update_post_meta( $post_id, "_manage_stock", "yes");
                                                            $in_stock_staus = 'instock';
                                                            wc_update_product_stock($post_id, $qty_on_hand, 'set' ,  true);
                                                            update_post_meta( $post_id, '_stock_status', wc_clean( $in_stock_staus ) );
                                                            wp_set_post_terms( $post_id, 'instock', 'product_visibility', true );
                                                            wc_delete_product_transients( $post_id ); 
                                                        }  
                                                       }
                                                      $product = wc_get_product( $post_id );
                                                      $product->set_regular_price($price);
                                                      $product->save();
                                                      
                                                  }    
                                                        
                                              }  
                                              else
                                              {
                                                        
                                                        update_post_meta( $post_id, '_sku', $code_sku );
                                                        if($product_quantity == 'Taip')
                                                             { 
                                                        if($qty_on_hand == 0)
                                                        {
                                                           $out_of_stock_staus = 'outofstock';
                                                           wc_update_product_stock($post_id, $qty_on_hand, 'set' ,  true);
                                                           update_post_meta( $post_id, '_stock_status', wc_clean( $out_of_stock_staus ) );
                                                           wp_set_post_terms( $post_id, 'outofstock', 'product_visibility', true );
                                                           wc_delete_product_transients( $post_id ); 
                                                        }
                                                        else
                                                        {
                                                            update_post_meta( $post_id, "_manage_stock", "yes");
                                                            $in_stock_staus = 'instock';
                                                            wc_update_product_stock($post_id, $qty_on_hand, 'set' ,  true);
                                                            update_post_meta( $post_id, '_stock_status', wc_clean( $in_stock_staus ) );
                                                            wp_set_post_terms( $post_id, 'instock', 'product_visibility', true );
                                                            wc_delete_product_transients( $post_id ); 
                                                        }
                                                        }  
                                                      $product = wc_get_product( $post_id );
                                                      $product->set_regular_price($price);
                                                      $product->save();
                                              }
									  		}
                                                                                           
                                            }
                                            
                                            
              $logs = json_decode($body, true);
              $status_code = $logs['result']['status_code'];
              $error = $logs['result']['error']; 
              $pluginlog = plugin_dir_path(__FILE__).'debug.log';
              $message = date('Y-m-d H:i:s') ." " ."[Get products from robolabs]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
              error_log($message, 3, $pluginlog);
                                             
             return $body;     
          }




add_action ('Cron_products_from_robo', 'get_products_from_robo');
?>