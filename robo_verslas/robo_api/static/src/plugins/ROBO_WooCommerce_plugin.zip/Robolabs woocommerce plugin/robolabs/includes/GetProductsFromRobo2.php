<?php   


function get_products_from_robo2()
{

              
              $currentDateTime = date('Y-m-d H:i:s');
              $api = get_option('robolabs_api_code');
              $endpoint = get_option('server_url');

               $data_api = array(
                  'secret' => $api,
                  'date_from' => "2000-01-01 0:00:00",
                  'date_to' =>  $currentDateTime,
                  'data_type' => "modify",
                  'execute_immediately' => true,
                  );
            
            
            
                          // send API request via cURL
            
                    $ch = curl_init();
                    
                    
                    curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/new_products");
            
                    curl_setopt($ch, CURLOPT_POST, 1);
            
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api));
                    
                    curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
            
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    
                    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                    

                    curl_setopt($ch, CURLOPT_VERBOSE, 1);
                    curl_setopt($ch, CURLOPT_HEADER, 1);
                    // ...
                  
                    $response = curl_exec($ch);

                    // Then, after your curl_exec call:
                    $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                    $header2 = substr($response, 0, $header_size);
                    $body2 = substr($response, $header_size);                                               
                    curl_close ($ch);
                
                    $products = json_decode($body2, true);
                                      foreach ($products["result"]["data"] as $produktu_masyvas)
                                            {
                                              
                                              $name = $produktu_masyvas['name'];
                                              $type = $produktu_masyvas['type'];
                                              $price = $produktu_masyvas['public_price'];
                                              $code_sku = $produktu_masyvas['code'];
                                              $variantukiekis = 0;
                                             

                                              $post = get_page_by_title( $name, OBJECT, 'product' );
                                              $post_id = $post->ID;
                                              if(isset($post_id))
                                              {
                                                   if($type == "service")
                                                   {
                                                        update_post_meta( $post_id, '_virtual', 'yes');
                                                   }
                                                   else
                                                   {
                                                        update_post_meta( $post_id, '_virtual', 'no');
                                                   }
                                                   
                                                   $product = wc_get_product( $post_id );
                                                      $product->set_regular_price($price);
                                                      $product->save();
                                                  
 
                                              
                                              
                                              }
                                              else
                                              {
                                              
                                                  $argsv = array(
                                                          'posts_per_page'     => -1,
                                                          'post_type'          => 'product_variation',
                                                          'suppress_filters'   => true
                                                      );
                                                  
                                                      $posts_array = get_posts( $argsv );
                                                  
                                                      foreach ( $posts_array as $post_array ) 
                                                      {
                                                          $skucode = get_post_meta( $post_array->ID, '_sku', true );
                                                          if($skucode == $code_sku)
                                                          {
                                                            if($type == "service")
                                                               {
                                                                    update_post_meta( $post_array->ID, '_virtual', 'yes');
                                                               }
                                                               else
                                                               {
                                                                    update_post_meta( $post_array->ID, '_virtual', 'no');
                                                               }
                                                              $product = wc_get_product( $post_array->ID );
                                                              $product->set_regular_price($price);
                                                              $product->save(); 
                                                              
                                                              
                                                              $variantukiekis = 1;
                                                          }                                                  
                                                      }
                                                if($variantukiekis == 0)
                                                {
                                                 $args = array(	   
                                                        	'post_author' => 1, 
                                                        	'post_content' => '',
                                                        	'post_status' => "draft", // (Draft | Pending | Publish)
                                                        	'post_title' => $name,
                                                        	'post_parent' => '',
                                                        	'post_type' => "product"
                                                        ); 
                                                        
                                                        // Create a simple WooCommerce product
                                                        $post_id = wp_insert_post( $args );
                                                        
                                                    if($type == "service")
                                                   {
                                                        update_post_meta( $post_id, '_virtual', 'yes');
                                                   }
                                                   else
                                                   {
                                                        update_post_meta( $post_id, '_virtual', 'no');
                                                   }
                                                   
                                                   $product = wc_get_product( $post_id );
                                                      $product->set_regular_price($price);
                                                      $product->save();
                                                }
                                              }
                                                                                           
                                            }
                    
              $logs = json_decode($body2, true);
              $status_code = $logs['result']['status_code'];
              $error = $logs['result']['error']; 
              $pluginlog = plugin_dir_path(__FILE__).'debug.log';
              $message = date("Y-m-d H:i:s") ." " ."[Get products from robolabs 2]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
              error_log($message, 3, $pluginlog);        
                          
          }
add_action ('Cron_products_from_robo2', 'get_products_from_robo2');