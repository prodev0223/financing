<?php 


function get_products_from_woo(){


                $api = get_option('robolabs_api_code');
                $endpoint = get_option('server_url');
                
                $data_api = array(
                        'secret' => $api,
                        'execute_immediately' => true,
                        );
                                // send API request via cURL
                  
                          $ch = curl_init();
                          
                          
                          curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/product_categories");
                  
                          curl_setopt($ch, CURLOPT_POST, 1);
                  
                          curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data_api));
                          
                          curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                  
                          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                          
                          curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                          

                          curl_setopt($ch, CURLOPT_VERBOSE, 1);
                          curl_setopt($ch, CURLOPT_HEADER, 1);
                          // ...
                        
                          $response = curl_exec($ch);

                          // Then, after your curl_exec call:
                          $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                          $header = substr($response, 0, $header_size);
                          $body = substr($response, $header_size);                                               
                          curl_close ($ch);
                          $categories = json_decode($body, true);
                          
                              
                
                $products = wc_get_products(array(
                    'numberposts' => -1,
                    'post_status' => 'published',
                ) );
              foreach($products as $preke)
              {
                    $name = $preke->get_name();
                    $default_code = $preke->get_sku();
                    $idpreke = $preke->get_id();
                    $category_id = $preke->get_category_ids();
                     
                    if( $term = get_term_by( 'id', $category_id[0], 'product_cat' ) ){
                        $woo_cat_name = $term->name;
                    }
                    foreach ($categories["result"]["data"] as $kategoriju_masyvas)
                                {
                                $cat_name =  $kategoriju_masyvas['name'];
                                      if($cat_name == $woo_cat_name)
                                      {
                                          $cat_id = $kategoriju_masyvas['id'];
                                      }
                                
                                }
                
                    
                    //Calculate product tax rate
                    $price = (float)$preke->get_price();
                    $price_with_vat = wc_get_price_including_tax($preke);
                        $tax_rate = (int)($price_with_vat * 100 / $price - 100);
                        if($tax_rate == 21.00)
                        {
                            $vats = "PVM1";
                        }
                        elseif($tax_rate == 9.00)
                        {
                            $vats = "PVM2";
                        }
                        elseif($tax_rate == 5.00)
                        {
                            $vats = "PVM3";
                        }
                        elseif($tax_rate == 0.00)
                        {
                            $vats = "Ne PVM";
                        }
                        
                        if ($preke-> is_virtual('yes')) 
                        {
                            $type = "service";
                        }
                        else
                        {
                            $type = "product";
                        }
                        if( $preke->is_type( 'variable' ) )
                        {
                            $variations = $preke->get_available_variations();
                            foreach($variations as $variation)
                            {
                                 foreach($variation['attributes'] as $atributas)
                                 {
                                 $name_variation = $name ." - ". $atributas;
                                 }
                                 $variationsku = $variation['sku'];
                                 $variationprice = $variation['display_price'];
                                 $variationprice1 = number_format($variationprice, 2, '.', ' ');
                                 $variationID = $variation['variation_id'];
                                 if($variationsku)  
                                {
                                 $product_datavariation = array(
                     
                                      'secret' => $api,
                                      'name' => $name_variation,
                                      'default_code' => $variationsku,
                                      'type' => $type,
                                      'vat_code' => $vats,
                                      'categ_id' => $cat_id,
                                      'price' => $variationprice1,
                                      'execute_immediately' => true,
                               
                               );
                               
                                $successfull_product_variations = get_option('successfull_product_variations');
                               if(!in_array($variationID, $successfull_product_variations))
                                        {
                      
                                        $ch = curl_init();
                  
                  
                                        curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/create_product");
                                
                                        curl_setopt($ch, CURLOPT_POST, 1);
                                
                                        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_datavariation));
                                        
                                        curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                                
                                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                        
                                        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                                        
                                        curl_setopt($ch, CURLOPT_VERBOSE, 1);
                                        
                                        curl_setopt($ch, CURLOPT_HEADER, 1);
                                      
                                        $response3 = curl_exec($ch);
                                
                                        // Then, after your curl_exec call:
                                        $header_size3 = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                                        $header3 = substr($response3, 0, $header_size3);
                                        $body3 = substr($response3, $header_size3);
                                                                                        
                                        curl_close ($ch);
                                        
                                        echo $body3;
                                        
                                        
                                        $tikrinimas3 = json_decode($body3, true);
                                        $tikrinimo_status_code3 = $tikrinimas3['result']['status_code'];
                                        if($tikrinimo_status_code3 == 200 or $tikrinimo_status_code3 == 401)
                                        {
          
                                                array_push($successfull_product_variations, $variationID);   
                                                update_option('successfull_product_variations' , $successfull_product_variations);   
                                        }
                              
                                        }
                               
                               
                               
                                }
                               
                            }
                        }
                     if($default_code)
                     {
                     $product_data = array(
                     
                            'secret' => $api,
                            'name' => $name,
                            'default_code' => $default_code,
                            'type' => $type,
                            'vat_code' => $vats,
                            'categ_id' => $cat_id,
                            'price' => $price,
                            'execute_immediately' => true,
                     
                     );
                      
                                $successfull_products = get_option('successfull_products');
                               if(!in_array($idpreke, $successfull_products))
                                        {
                      
                              $ch = curl_init();
        
        
                              curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/create_product");
                      
                              curl_setopt($ch, CURLOPT_POST, 1);
                      
                              curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($product_data));
                              
                              curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                      
                              curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                              
                              curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                              
                              curl_setopt($ch, CURLOPT_VERBOSE, 1);
                              
                              curl_setopt($ch, CURLOPT_HEADER, 1);
                            
                              $response1 = curl_exec($ch);
                      
                              // Then, after your curl_exec call:
                              $header_size1 = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                              $header1 = substr($response1, 0, $header_size1);
                              $body2 = substr($response1, $header_size1);
                                                                              
                              curl_close ($ch);
                            
                              
                              $tikrinimas = json_decode($body2, true);
                              $tikrinimo_status_code = $tikrinimas['result']['status_code'];
                              if($tikrinimo_status_code == 200 or $tikrinimo_status_code == 401)
                              {

                                      array_push($successfull_products, $idpreke);   
                                      update_option('successfull_products' , $successfull_products);   
                              }
                              
                                        }
                        }                         
                      
              }
              
                         
              $logs = json_decode($body2, true);
              $status_code = $logs['result']['status_code'];
              $error = $logs['result']['error']; 
              $pluginlog = plugin_dir_path(__FILE__).'debug.log';
              $message = date('Y-m-d H:i:s') ." " ."[Get products from woocoomerce]". "   " . "Status code:" . $status_code . "  " . "Error:". $error .PHP_EOL;
              error_log($message, 3, $pluginlog); 
              
              
      
}
 add_action ('Cron_products_from_woo', 'get_products_from_woo');
?>