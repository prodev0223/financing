<?php
   /*
   Plugin Name: Robolabs &#303;skiepis
   Plugin URI: Robolabs.lt
   Description: Robolabs &#303;skiepis
   * Text Domain: robolabs
   Version: 1.9.9
   Author: Robolabs
   License: GPL3
   */
   
   
   
   
      
   function plugin_name_load_plugin_textdomain() {

	$domain = 'robolabs';
	$locale = apply_filters( 'plugin_locale', get_locale(), $domain );

	if ( $loaded = load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '/' . $domain . '-' . $locale . '.mo' ) ) {
		return $loaded;
	} else {
		load_plugin_textdomain( $domain, FALSE, basename( dirname( __FILE__ ) ) . '/languages/' );
	}

}
add_action( 'init', 'plugin_name_load_plugin_textdomain' );
   
    function delete_options_deactivation()
    {     
    delete_option('robolabs_api_code');
    delete_option('robolabs_date_from');
    delete_option('journal_series');
    delete_option('robowarehouse');
    delete_option('server_url');
    delete_option('ProductSync');
    delete_option('Orderstatus');
    delete_option('successfull_orders'); 
    delete_option('successfull_products');  
    delete_option('successfull_categories');    
    }
    register_deactivation_hook (__FILE__, 'delete_options_deactivation');



    function robolabs_function()
    {
                   
    
    }
    
    function robolabs_plugin_settings_link($links) 
    { 
        $settings_link = '<a href="options-general.php?page=robolabs-admin-menu">Settings</a>'; 
        array_unshift($links, $settings_link); 
        return $links; 
    }
        $plugin = plugin_basename(__FILE__); 
        add_filter("plugin_action_links_$plugin", 'robolabs_plugin_settings_link' );
    
    function robolabs_scripts() 
    {    
        $plugin_url = plugin_dir_url( __FILE__ );
        wp_enqueue_style( 'style',  $plugin_url . "/style/robo.css");
    }

    add_action( 'admin_print_styles', 'robolabs_scripts' );
    
    
    function robolabs_admin_menu_option()
    {
          add_menu_page('Robolabs Plugin' , 'Robolabs' , 'manage_options' , 'robolabs-admin-menu' , 'robolabs_admin_page', plugin_dir_url( __FILE__ ) . '/image/favicon1.png' , 200);
              
    }
   
     add_action('admin_menu' , 'robolabs_admin_menu_option');

    
    
    
    
        function cronstarter_activation0() 
    {
    	if( !wp_next_scheduled( 'Cron_orders_status' ) ) 
      {  
    	   wp_schedule_event( strtotime('22:00:00'), 'daily', 'Cron_orders_status' );  
    	}
    }
           add_action('wp', 'cronstarter_activation0');
           
    function cronstarter_deactivate0() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_orders_status');
    	wp_unschedule_event ($timestamp, 'Cron_orders_status');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate0');
    
    
    
    
    
    
    
    function cronstarter_activation1() 
    {
    	if( !wp_next_scheduled( 'Cron_categories_from_robo' ) ) 
      {  
    	   wp_schedule_event( strtotime('22:30:00'), 'daily', 'Cron_categories_from_robo' );  
    	}
    }
           add_action('wp', 'cronstarter_activation1');
           
    function cronstarter_deactivate1() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_categories_from_robo');
    	wp_unschedule_event ($timestamp, 'Cron_categories_from_robo');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate1');
    
    
    
    
    
    
    function cronstarter_activation2() 
    {
    	if( !wp_next_scheduled( 'Cron_categories_from_woo' ) ) 
      {  
    	   wp_schedule_event( strtotime('23:00:00'), 'daily', 'Cron_categories_from_woo' );  
    	}
    }
           add_action('wp', 'cronstarter_activation2');
           
    function cronstarter_deactivate2() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_categories_from_woo');
    	wp_unschedule_event ($timestamp, 'Cron_categories_from_woo');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate2');    
    
    
    
    
    
    
    
    function cronstarter_activation3() 
    {
    	if( !wp_next_scheduled( 'Cron_products_from_robo' ) ) 
      {  
    	   wp_schedule_event( strtotime('00:00:00'), 'daily', 'Cron_products_from_robo' );  
    	}
    }
           add_action('wp', 'cronstarter_activation3');
           
    function cronstarter_deactivate3() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_products_from_robo');
    	wp_unschedule_event ($timestamp, 'Cron_products_from_robo');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate3');   
    
    
    
    
        function cronstarter_activation4() 
    {
    	if( !wp_next_scheduled( 'Cron_products_from_robo2' ) ) 
      {  
    	   wp_schedule_event( strtotime('00:30:00'), 'daily', 'Cron_products_from_robo2' );  
    	}
    }
           add_action('wp', 'cronstarter_activation4');
           
    function cronstarter_deactivate4() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_products_from_robo2');
    	wp_unschedule_event ($timestamp, 'Cron_products_from_robo2');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate4');    
    
    
    
    
    
    function cronstarter_activation5() 
    {
    	if( !wp_next_scheduled( 'Cron_products_from_woo' ) ) 
      {  
    	   wp_schedule_event( strtotime('23:30:00'), 'daily', 'Cron_products_from_woo' );  
    	}
    }
           add_action('wp', 'cronstarter_activation5');
           
    function cronstarter_deactivate5() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_products_from_woo');
    	wp_unschedule_event ($timestamp, 'Cron_products_from_woo');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate5');
    
    
    
    
    
    function cronstarter_activation6() 
    {
    	if( !wp_next_scheduled( 'Cron_orders_from_woo' ) ) 
      {  
    	   wp_schedule_event( strtotime('01:30:00'), 'daily', 'Cron_orders_from_woo' );  
    	}
    }
           add_action('wp', 'cronstarter_activation6');
           
    function cronstarter_deactivate6() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_orders_from_woo');
    	wp_unschedule_event ($timestamp, 'Cron_orders_from_woo');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate6');
    
    
    
    
    function cronstarter_activation7() 
    {
    	if( !wp_next_scheduled( 'Cron_orders_refund' ) ) 
      {  
    	   wp_schedule_event( strtotime('02:00:00'), 'daily', 'Cron_orders_refund' );  
    	}
    }
           add_action('wp', 'cronstarter_activation7');
           
    function cronstarter_deactivate7() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_orders_refund');
    	wp_unschedule_event ($timestamp, 'Cron_orders_refund');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate7'); 
    
    
    function cronstarter_activation8() 
    {
    	if( !wp_next_scheduled( 'delete_logs' ) ) 
      {  
    	   wp_schedule_event( strtotime('22:00:00'), 'weekly', 'delete_logs' );  
    	}
    }
           add_action('wp', 'cronstarter_activation8');
           
    function cronstarter_deactivate8() 
    {	
    	$timestamp = wp_next_scheduled ('delete_logs');
    	wp_unschedule_event ($timestamp, 'delete_logs');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate8');


     function run_delete_logs()
     {
          $file = dirname( __FILE__ )  . '/includes/debug.log';
          unlink($file);
     }
      add_action ('delete_logs', 'run_delete_logs');
      
      
       function cronstarter_activation9() 
    {
    	if( !wp_next_scheduled( 'Cron_jobs_from_robo' ) ) 
      {  
    	   wp_schedule_event( strtotime('03:00:00'), 'daily', 'Cron_jobs_from_robo' );  
    	}
    }
           add_action('wp', 'cronstarter_activation9');
           
    function cronstarter_deactivate9() 
    {	
    	$timestamp = wp_next_scheduled ('Cron_jobs_from_robo');
    	wp_unschedule_event ($timestamp, 'Cron_jobs_from_robo');
    } 
    register_deactivation_hook (__FILE__, 'cronstarter_deactivate9');









        function run_get_orders_status()
    {

       include "includes/GetOrderStatus.php";
       get_orders_status();
    }  
    add_action ('Cron_orders_status', 'run_get_orders_status');


    function run_get_products_from_woo()
    {
       $product_sync = get_option('ProductSync');
       if($product_sync == 'Syncfromwoo' or $product_sync == 'Syncfromboth')
       {
       include "includes/GetProductsFromWoo.php";
       get_products_from_woo();
       }
    }  
    add_action ('Cron_products_from_woo', 'run_get_products_from_woo');
    
    
        function run_get_orders_from_woo()
    {
       include "includes/GetOrdersFromWoo.php";
       get_orders_from_woo();
    }  
    add_action ('Cron_orders_from_woo', 'run_get_orders_from_woo');
    
    
    
    function run_get_products_from_robo()
    {
        $product_sync = get_option('ProductSync');
       if($product_sync == 'Syncfromrobo' or $product_sync == 'Syncfromboth')
       {
       include "includes/GetProductsFromRobo.php";
       get_products_from_robo();
       }
    }  
    add_action ('Cron_products_from_robo', 'run_get_products_from_robo');
    
    
    
    function run_get_products_from_robo2()
    {
      $product_sync = get_option('ProductSync');
       if($product_sync == 'Syncfromrobo' or $product_sync == 'Syncfromboth')
       {
       include "includes/GetProductsFromRobo2.php";
       get_products_from_robo2();
       }
    }  
    add_action ('Cron_products_from_robo2', 'run_get_products_from_robo2');
    
    
    
    function run_get_categories_from_woo()
    {
      $product_sync = get_option('ProductSync');
       if($product_sync == 'Syncfromwoo' or $product_sync == 'Syncfromboth')
       {
       include "includes/GetCategoriesFromWoo.php";
       get_categories_from_woo();
       }
    }  
    add_action ('Cron_categories_from_woo', 'run_get_categories_from_woo');
    
    
        
    
    function run_get_categories_from_robo()
    {   
      $product_sync = get_option('ProductSync');
       if($product_sync == 'Syncfromrobo' or $product_sync == 'Syncfromboth')
       {
       include "includes/GetCategoriesFromRobo.php";
       get_categories_from_robo();
       }
    }  
    add_action ('Cron_categories_from_robo', 'run_get_categories_from_robo');



    function run_refund_from_woo()
    {
       include "includes/GetOrdersRefund.php";
       get_orders_refund();
    }  
    add_action ('Cron_orders_refund', 'run_refund_from_woo');


    function run_get_api_jobs()
    {
       include "includes/GetJobFromRobo.php";
       get_api_jobs();
    }  
    add_action ('Cron_jobs_from_robo', 'run_get_api_jobs');



      function robolabs_admin_page()
      {
           if(array_key_exists('submit_settings_robo',$_POST))
           {
                update_option('robolabs_api_code',$_POST['api_code']);
                update_option('robolabs_date_from',$_POST['robolabs_date']);
                update_option('journal_series',$_POST['journal_series']);
                update_option('robowarehouse',$_POST['robowarehouse']);
                update_option('server_url',$_POST['server_url']);
                update_option('ProductSync',$_POST['ProductSync']);
                update_option('Orderstatus',$_POST['orderstatus']);
                update_option('ProductQuantity',$_POST['ProductQuantity']);
                ?>
                <div id="setting-error-settings_updated" class="notice notice-success is-dismissible"><strong><?php _e('Pasirinkimai i&#x161;saugoti','robolabs') ?></strong></div>
                <?php
                                       $successfull_orders = get_option('successfull_orders');
                                       if($successfull_orders == null)
                                       {
                                       $successfull_orders = array();
                                       array_push($successfull_orders, 0);
                                       update_option('successfull_orders' , $successfull_orders);
                                       }
                                       
                                       $successfull_products = get_option('successfull_products');
                                       if($successfull_products == null)
                                       {
                                       $successfull_products = array();
                                       array_push($successfull_products, 0);
                                       update_option('successfull_products' , $successfull_products);
                                       }
                                       
                                       $successfull_categories = get_option('successfull_categories');
                                       if($successfull_categories == null)
                                       {
                                        $successfull_categories = array();
                                        array_push($successfull_categories, 0);
                                        update_option('successfull_categories' , $successfull_categories);
                                       }
                                       
                                       $successfull_product_variations = get_option('successfull_product_variations');
                                       if($successfull_product_variations == null)
                                       {
                                        $successfull_product_variations = array();
                                        array_push($successfull_product_variations, 0);
                                        update_option('successfull_product_variations' , $successfull_product_variations);
                                       }
                                       
                                       
                                       $api = get_option('robolabs_api_code');
                                       $endpoint = get_option('server_url');
                                       
                                       $order_data = array(

                                  'secret' => $api,
                                  'execute_immediately' => true,
                                  );
                                      $ch = curl_init();
                                      
                                      
                                      curl_setopt($ch, CURLOPT_URL, $endpoint . "/api/product_categories");
                              
                                      curl_setopt($ch, CURLOPT_POST, 1);
                              
                                      curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($order_data));
                                      
                                      curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json; charset=UTF-8'));
                              
                                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                                      
                                      curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
                                      
         
                                      curl_setopt($ch, CURLOPT_VERBOSE, 1);
                                      curl_setopt($ch, CURLOPT_HEADER, 1);
                                      // ...
                                    
                                      $response = curl_exec($ch);

                                      // Then, after your curl_exec call:
                                      $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
                                      $header = substr($response, 0, $header_size);
                                      $body = substr($response, $header_size); 
                                                                                      
                                      curl_close ($ch);
                                      
                                      $logs = json_decode($body, true);
                                      $status_code = $logs['result']['status_code'];
                                      if($status_code != 200)
                                      {
                                          ?>
                                         <div id="setting-error-settings_updated" class="notice notice-error is-dismissible"><strong><?php _e('Blogai ivestas API kodas arba serverio nuoroda','robolabs') ?></strong></div>
                                         <?php 
                                      } 
                                      
                                    
        
           }
           $api_code = get_option('robolabs_api_code');
           $robolabs_date_from = get_option('robolabs_date_from');
           $journal_series =  get_option('journal_series');
           $robowarehouse =  get_option('robowarehouse');
           $server_url =  get_option('server_url');
           $product_sync = get_option('ProductSync');
           $orderstatus = get_option('Orderstatus'); 
           $product_quantity = get_option('ProductQuantity');
         
     /*     
          if(array_key_exists('send_orders_to_robo',$_POST))
          { 
            require_once "includes/GetOrdersFromWoo.php";
            get_orders_from_woo();
            //require_once "includes/GetOrderStatus.php";
            // get_orders_status();
          } 
          
          if(array_key_exists('send_products_to_robo',$_POST))
          {
              require_once "includes/GetProductsFromWoo.php";
              get_products_from_woo();               
          } 
            
          if(array_key_exists('send_product_categories_to_robo',$_POST))
          {
              require_once "includes/GetCategoriesFromWoo.php";
              $body = get_categories_from_woo();      
          }
          
         if(array_key_exists('get_products_from_robo',$_POST))
          {                      
              require_once "includes/GetProductsFromRobo.php";
              //require_once "includes/GetProductsFromRobo2.php";
              get_products_from_robo();
              //get_products_from_robo2();                                                         
          }
              
           if(array_key_exists('get_categories_from_robo',$_POST))
          {
              require_once "includes/GetCategoriesFromRobo.php";
              $body = get_categories_from_robo();
          }
          
          if(array_key_exists('refund',$_POST))
          {
              require_once "includes/GetOrdersRefund.php";
            get_orders_refund();
          }
             
         
       
             
            */    
           ?>        
           
<style>
* {
  box-sizing: border-box;
}


.column {
  float: left;
  width: 50%;
  padding: 10px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}


#table-wrapper {
  position:relative;
}
#table-scroll {
  height:250px;
  overflow:auto;  
  margin-top:20px;
}
#table-wrapper table {
  width:100%;

}

#table-wrapper table thead th .text {
  position:absolute;   
  top:-20px;
  z-index:2;
  height:20px;
  width:35%;
  border:1px solid red;
}
</style>  


 
<div class="wrap">
<h1><?php _e('Robolabs integracija','robolabs'); ?></h1>
 <div class="row">
  <div class="column"> 
<form method="post" name="roboforma">
    <table class="form-table">
        <tr valign="top">
        <th scope="row"><?php _e('API Kodas','robolabs'); ?></th>
        <td><input type="text" name="api_code" placeholder= "awd456468a" value="<?php print $api_code; ?>"></td>  
        </tr>
         
        <tr valign="top">
        <th scope="row"><?php _e('Sinchronizacijos data nuo:','robolabs'); ?></th>
        <td><input type="text" name="robolabs_date" placeholder= "YYYY-MM-DD" value="<?php print $robolabs_date_from; ?>" ></td>
        </tr>
        
        <tr valign="top">
        <th scope="row"><?php _e('Saskait&#x173; serija:','robolabs'); ?></th>
        <td><input type="text" name="journal_series" placeholder= "INV" value="<?php print $journal_series; ?>" ></td>
        </tr>
        
        <tr valign="top">
        <th scope="row"><?php _e('Sandelio pavadinimas:','robolabs'); ?></th>
        <td><input type="text" name="robowarehouse" placeholder= "WH" value="<?php print $robowarehouse; ?>" ></td>
        </tr>
        
        <tr valign="top">
        <th scope="row"><?php _e('Serverio nuoroda:','robolabs'); ?></th>
        <td><input type="text" name="server_url" placeholder= "https://api.robolabs.lt" value="<?php print $server_url; ?>" ></td>
        </tr>
        
        <tr valign="top">
        <th scope="row"><?php _e('Produkt&#371 sinchronizacijos pasirinkimai:','robolabs'); ?></th>
        <td><input type="radio" name="ProductSync" value="Nosync" <?php if  ($product_sync == 'Nosync') echo 'checked'; ?> > <?php _e('Nesinchronizuoti','robolabs'); ?><br>
            <input type="radio" name="ProductSync" value="Syncfromrobo" <?php if  ($product_sync == 'Syncfromrobo') echo 'checked'; ?> > <?php _e('Sinchronizuoti i&#353 robolabs ','robolabs'); ?><br>
            <input type="radio" name="ProductSync" value="Syncfromwoo" <?php if  ($product_sync == 'Syncfromwoo') echo 'checked'; ?> > <?php _e('Sinchronizuoti i&#353 Woocommerce ','robolabs'); ?><br>
            <input type="radio" name="ProductSync" value="Syncfromboth" <?php if  ($product_sync == 'Syncfromboth') echo 'checked'; ?> > <?php _e(' i&#353 abiej&#371','robolabs'); ?></td>
        </tr>
        
        <tr valign="top">
        <th scope="row"><?php _e('Ar sinchronizuoti produkt&#371 kiekius?','robolabs'); ?></th>
        <td><input type="radio" name="ProductQuantity" value="Taip" <?php if  ($product_quantity == 'Taip') echo 'checked'; ?> > <?php _e('Taip','robolabs'); ?><br>
            <input type="radio" name="ProductQuantity" value="Ne" <?php if  ($product_quantity == 'Ne') echo 'checked'; ?> > <?php _e('Ne','robolabs'); ?><br>
        </tr>
        
        
        
        <tr valign="top">
            <th scope="row"><?php _e('U&#382;sakym&#371; statuso pasirinkimas:','robolabs'); ?></th>
            <td><select id="orderstatus" name="orderstatus">
        <?php
            $order_statuses = wc_get_order_statuses();
            foreach($order_statuses as $key=>$status)
            {
               ?>
               
            <option value="<?php echo $key ?>" <?php if  ($orderstatus == $key ) echo 'selected'; ?> > <?php echo $status ?></option>
            
            
            <?php     
            }
        ?>
                </select></td>
        </tr>
        
    </table>
    
    <input type="submit" name="submit_settings_robo" class="button button-primary" value=<?php _e('I&#x161;saugoti','robolabs') ?>>
    <br><br>
 <!--    
    <form method="post" action"">
          <input type="submit" name="send_orders_to_robo" class="button button-primary" value=<?php _e('Siusti_uzsakymus','robolabs') ?>>
    </form>   
   
    <form method="post" action"">
          <input type="submit" name="refund" class="button button-primary" value="Refund">
    </form>
            
    <br>
    <form method="post" action"">
          <input type="submit" name="send_products_to_robo" class="button button-primary" value="Si&#x173;sti prekes &#x12F; Robolabs">
    </form>   
    
<br>
    <form method="post" action"">
          <input type="submit" name="send_product_categories_to_robo" class="button button-primary" value="Si&#x173;sti preki&#x173; kategorijas &#x12F; Robolabs">
    </form>
    
    
      <br>
    <form method="post" action"">
          <input type="submit" name="get_products_from_robo" class="button button-primary" value="Gauti prekes">
    </form>
         <br>
    <form method="post" action"">
          <input type="submit" name="get_categories_from_robo" class="button button-primary" value="Gauti kategorijas">
    </form>
        <br>
      
    
 -->               
                
                
                
                
</div>


      <div class="column">


        <h1><?php _e('Robolabs Dokumentacija','robolabs') ?></h1>
        <p><?php _e('1. &#302 API kodas laukel&#303 &#303ra&#353ykite duot&#261 api kod&#261 kuris randasi robolabs sistemoje, kompanijos profilis lange, puslapio apa&#269ioje skiltyje ROBO API.
        <br>
        2. &#302 Sinchronizacijos data nuo laukel&#303 &#303ra&#353ykite dat&#261 nuo kurios norite sinchronizuoti u&#382sakymus formatu YYYY-MM-DD.
        <br>
        3. &#302 s&#261skait&#371 serijos laukel&#303 &#303ra&#353ykite savo s&#261skait&#371 serijos pavadinim&#261.
        <br>
        4. &#302 sandelio pavadinimo laukel&#303 &#303ra&#353ykite savo sukurto sand&#279lio pavadinim&#261 kaip robolabs sistemoje, o jei nek&#363r&#279te jokio sand&#279lio &#303ra&#353ykite WH.
        <br>
        5. &#302 serverio nuorodos laukel&#303 &#303ra&#353ykite URL kuriuo jungiates prie robolabs sistemos pvz:https://api.robolabs.lt     
        <br>
        6. Pasirinkite produkt&#371 sinchronizacijos b&#363d&#261.   
        <br>
        7. Visk&#261 u&#382pild&#382ius spauskite mygtuk&#261 i&#353saugoti.
        <br>
        8. Sistema kiekvien&#261 dien&#261 automati&#353kai sinchronizuos duomenis.
        <br>
        Papildoma informacija
        <br>
        1. Sistema u&#382sakymus sinchronizuos tik tuos kurie yra &#303vykdyti.
        <br>
        2. I&#353 robolabs sistemos produktus &#303 woocommerce atvaizduos kaip juodra&#353&#269ius.
        <br>
        3. Prek&#279s neturin&#269ios prek&#279s kodo nebus siun&#269iamos i&#353 woocommerce &#303 robolabs.  ','robolabs') ?></p>
        <br>
       <h2><?php _e('Klaid&#371 lentel&#279','robolabs') ?></h2>
       
    <div id="table-wrapper">
    <div id="table-scroll">
       <table class="widefat fixed" cellspacing="0">

        
         <tr>
              <th>ID</th>
              <th><?php _e('Klaidos numeris','robolabs') ?></th> 
              <th><?php _e('Klaida','robolabs') ?></th>
              <th><?php _e('Bandyt i&#353 naujo','robolabs') ?></th>
        </tr>
        
        <?php
       
        $main_body_array = get_option('orders_error');
        $successfull_orders = get_option('successfull_orders');
            foreach($main_body_array as $body)
             {
                    $logs = json_decode($body, true);
                    $id = $logs['id'];
                    $status_code = $logs['result']['status_code'];
                    $error = $logs['result']['error'];
                    $api_job_id = $logs['result']['data']['api_job_id'];
                    $journal_number =  $journal_series . $id;
                    if($status_code != 200 && $error != "Invoice with " .  $journal_number . " number already exists.")
                    {
                        echo "<tr>";
                        echo "<td>" . $id . "</td>";
                        echo "<td>" .  $status_code . "</td>";
                        echo "<td>" .  $error . "</td>";
                        echo  "<td>" . "<form method='post' action''>" .  " <input type= 'submit' name='retry' class='button button-primary' value='&#128472'> " . "</form>". "</td>";
                        echo "</tr>";
                        
                                  
          
                        
                    }
                     if($status_code == 200)
                     {
                            if(!$api_job_id)
                            {
                            
                            array_push($successfull_orders, $id);   
                            }
                     }

                     
                   if(array_key_exists('retry',$_POST))
                                    { 
                                        require_once "includes/GetOrdersFromWoo.php";
                                         $body_array = get_orders_from_woo();
                                          update_option('orders_error' , $body_array , $autoload = 'yes');
                                          header('Location: '.$_SERVER['REQUEST_URI']);
                                    }  
                     
             }
             update_option('successfull_orders' , $successfull_orders);
         ?>
         
        
       </table>
      </div>
      </div>
      </div>
</div>
<script>
function refreshPage(){
    window.location.reload();
} 
</script>
          <?php
      }
      
      
      
      
      
//Add vat number to checkout page      
add_action( 'woocommerce_before_order_notes', 'robo_add_custom_checkout_field_VAT' );
  
function robo_add_custom_checkout_field_VAT( $checkout ) { 
   woocommerce_form_field( 'VAT_number', array(        
      'type' => 'text',        
      'class' => array( 'form-row-wide' ),        
      'label' => _e('<label> PVM Kodas </label>','robolabs'),               
      'required' => false,                
   ), $checkout->get_value( 'VAT_number' ) ); 
}
   
add_action( 'woocommerce_checkout_process', 'robo_validate_new_checkout_field_VAT' );
  
function robo_validate_new_checkout_field_VAT() {    
   if ( $_POST['billing_company'] && ! $_POST['VAT_number']  ) {  
     
       wc_add_notice ( __('Prašome įvesti PVM kodą','robolabs'), 'error' );  
   }
}

add_action( 'woocommerce_checkout_update_order_meta', 'robo_save_new_checkout_field_VAT' );
  
function robo_save_new_checkout_field_VAT( $order_id ) { 
    if ( $_POST['VAT_number'] ) update_post_meta( $order_id, '_VAT_number', esc_attr( $_POST['VAT_number'] ) );
}
  
add_action( 'woocommerce_admin_order_data_after_billing_address', 'robo_show_new_checkout_field_order_VAT', 10, 1 );
   
function robo_show_new_checkout_field_order_VAT( $order ) {    
   $order_id = $order->get_id();
   if ( get_post_meta( $order_id, '_VAT_number', true ) ) echo '<p><strong>PVM kodas:</strong> ' . get_post_meta( $order_id, '_VAT_number', true ) . '</p>';
}
 
add_action( 'woocommerce_email_after_order_table', 'robo_show_new_checkout_field_emails_VAT', 20, 4 );
  
function robo_show_new_checkout_field_emails_VAT( $order, $sent_to_admin, $plain_text, $email ) {
    if ( get_post_meta( $order->get_id(), '_VAT_number', true ) ) echo '<p><strong>PVM kodas:</strong> ' . get_post_meta( $order->get_id(), '_VAT_number', true ) . '</p>';
}   


//Add company code to checkout page
add_action( 'woocommerce_before_order_notes', 'robo_add_custom_checkout_field' );
  
function robo_add_custom_checkout_field( $checkout ) { 
   woocommerce_form_field( 'company_code', array(        
      'type' => 'text',        
      'class' => array( 'form-row-wide' ),        
      'label' => _e('<label> Įmonės kodas </label>','robolabs'),              
      'required' => false,                
   ), $checkout->get_value( 'company_code' ) ); 
}
   
add_action( 'woocommerce_checkout_process', 'robo_validate_new_checkout_field' );
  
function robo_validate_new_checkout_field() {    
   if ( $_POST['billing_company'] && ! $_POST['company_code'] ) {
      wc_add_notice( __('Prašome įvesti įmonės kodą','robolabs'), 'error' );
   }
}

add_action( 'woocommerce_checkout_update_order_meta', 'robo_save_new_checkout_field' );
  
function robo_save_new_checkout_field( $order_id ) { 
    if ( $_POST['company_code'] ) update_post_meta( $order_id, '_company_code', esc_attr( $_POST['company_code'] ) );
}
  
add_action( 'woocommerce_admin_order_data_after_billing_address', 'robo_show_new_checkout_field_order', 10, 1 );
   
function robo_show_new_checkout_field_order( $order ) {    
   $order_id = $order->get_id();
   if ( get_post_meta( $order_id, '_company_code', true ) ) echo '<p><strong>Įmonės kodas:</strong> ' . get_post_meta( $order_id, '_company_code', true ) . '</p>';
}
 
add_action( 'woocommerce_email_after_order_table', 'robo_show_new_checkout_field_emails', 20, 4 );
  
function robo_show_new_checkout_field_emails( $order, $sent_to_admin, $plain_text, $email ) {
    if ( get_post_meta( $order->get_id(), '_company_code', true ) ) echo '<p><strong>Įmonės kodas:</strong> ' . get_post_meta( $order->get_id(), '_company_code', true ) . '</p>';
}   
   
   
   
   
   
?>
